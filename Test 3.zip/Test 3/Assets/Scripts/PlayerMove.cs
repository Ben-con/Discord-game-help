using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    //Public variables
    public float MovementSpeed = 1f;
    public float JumpForce = 1f;
   
    

    //seritalizedfields
    [SerializeField] private LayerMask jumpableGround;
    [SerializeField] private float SlopeCheckDistance;
   
    
    
    //private variables
    private float coyoteTime = 0.2f;
    private float coyoteTimeCounter;
    private float jumpBufferTime = .2f;
    private float jumpBufferCounter;
    private float FallGravityMultiplier = 2;
    
    private Rigidbody2D _rigidbody;
    private CapsuleCollider2D _capsulecollider;
    private BoxCollider2D _boxCollider;

    


    
    void Start()
    {
        //selects the rigid body when the game starts
        _rigidbody = GetComponent<Rigidbody2D>();
        _capsulecollider = GetComponent<CapsuleCollider2D>();
        _boxCollider = GetComponent<BoxCollider2D>();
       
    }

     private void FixedUpdate() {
        IsGrounded();
        
    }

   
    void Update()
    {

        
        
        
        // Moves player--------
        var movement = Input.GetAxis("Horizontal");
        transform.position += new Vector3(movement, 0, 0) * Time.deltaTime * MovementSpeed;
        //-----------------------

       
        if(IsGrounded()){
            coyoteTimeCounter = coyoteTime;
        }else{
            coyoteTimeCounter -= Time.deltaTime;
        }

        if(Input.GetButtonDown("Jump"))
        {
            jumpBufferCounter = jumpBufferTime;
        }else{
            jumpBufferCounter -= Time.deltaTime;
        }
        

        // Makes player jump ------------
            // Player can jump if they have jumps remaining and have pressed the jump button
        if(jumpBufferCounter > 0f && coyoteTimeCounter > 0f)
        {
            // add upwards force to make the player jump
            
            _rigidbody.velocity = new Vector2(_rigidbody.velocity.x,JumpForce);
            
            jumpBufferCounter =0f;
            
        }

        // Makes the player be able to control their jumps by releasing the "Jump key"
        if(Input.GetButtonUp("Jump") && _rigidbody.velocity.y > 0f)
            { 
                _rigidbody.velocity = new Vector2(_rigidbody.velocity.x, _rigidbody.velocity.y * .5f);  
                coyoteTimeCounter = 0f;
            }

             if(_rigidbody.velocity.y < 0) 
             {
            _rigidbody.gravityScale = 2 * FallGravityMultiplier;
             }else
             {
            _rigidbody.gravityScale =  2;
             }
    }


    private bool IsGrounded()
        {
           
            float extraheight = .1f;
            RaycastHit2D raycastHit = Physics2D.BoxCast(_boxCollider.bounds.center, _boxCollider.bounds.size - new Vector3(.1f, 0f, 0f), 0f, Vector2.down, extraheight, jumpableGround);
            Color rayColor;
            if(raycastHit.collider != null){
                rayColor = Color.green;
            }else{
                rayColor = Color.red;
            }

            // Debug.DrawRay(_boxCollider.bounds.center + new Vector3(_boxCollider.bounds.extents.x, 0), Vector2.down * (_boxCollider.bounds.extents.y + extraheight), rayColor);
            // Debug.DrawRay(_boxCollider.bounds.center - new Vector3(_boxCollider.bounds.extents.x, 0), Vector2.down * (_boxCollider.bounds.extents.y + extraheight), rayColor);
            // Debug.DrawRay(_boxCollider.bounds.center - new Vector3(_boxCollider.bounds.extents.x, _boxCollider.bounds.extents.y + extraheight), Vector2.right * (_boxCollider.bounds.extents.x), rayColor);
            // Debug.DrawRay(_boxCollider.bounds.center + new Vector3(_boxCollider.bounds.extents.x, _boxCollider.bounds.extents.x + extraheight), Vector2.left * (_boxCollider.bounds.extents.x), rayColor);

            // Debug.Log(raycastHit.collider);
            return raycastHit.collider != null;

       
        }
}   
